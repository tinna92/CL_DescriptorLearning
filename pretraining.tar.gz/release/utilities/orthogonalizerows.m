function B = orthogonalizerows(A)

B = real((A*A')^(-0.5))*A;



